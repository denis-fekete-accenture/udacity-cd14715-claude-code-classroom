export const validReport = {
  "pullRequest": {
    "owner": "octocat",
    "repo": "Hello-World",
    "number": 1
  },
  "fileReviews": [
    {
      "file": "README",
      "codeQuality": {
        "file": "README",
        "issues": [
          {
            "line": 1,
            "severity": "medium",
            "category": "maintainability",
            "description": "README file lacks proper documentation structure and informative content",
            "suggestion": "Add a comprehensive README with project description, installation instructions, usage examples, contribution guidelines, and license information. Consider using Markdown format (README.md) for better formatting and readability."
          },
          {
            "line": 1,
            "severity": "low",
            "category": "best-practice",
            "description": "README file does not follow modern documentation standards",
            "suggestion": "Rename to README.md and use Markdown formatting. Include sections such as: project title, description, features, installation, usage, contributing, tests, license, and contact information."
          },
          {
            "line": 1,
            "severity": "info",
            "category": "maintainability",
            "description": "Missing project metadata and badges",
            "suggestion": "Consider adding badges for build status, test coverage, version, license, and other relevant project metrics at the top of the README to provide quick project insights."
          },
          {
            "line": 1,
            "severity": "info",
            "category": "best-practice",
            "description": "No usage examples or getting started guide",
            "suggestion": "Include a 'Getting Started' or 'Quick Start' section with basic usage examples to help users understand how to use the project immediately."
          },
          {
            "line": 1,
            "severity": "info",
            "category": "maintainability",
            "description": "Missing contribution guidelines",
            "suggestion": "Add a 'Contributing' section or link to CONTRIBUTING.md to encourage community participation and set clear expectations for contributors."
          }
        ],
        "overallScore": 45,
        "summary": "The README file contains minimal content ('Hello World!') and lacks essential documentation elements. While there are no security or performance concerns for a plain text documentation file, it significantly falls short on maintainability and best practices. A comprehensive README should include project description, installation instructions, usage examples, contribution guidelines, and license information. Converting to Markdown format (README.md) would enable better formatting and readability. The file serves as a placeholder but does not provide meaningful documentation value for users or contributors."
      },
      "testCoverage": {
        "file": "README",
        "hasTests": false,
        "testFiles": [],
        "untestedPaths": [],
        "coverageEstimate": 100,
        "summary": "The README file is a documentation file containing only the text 'Hello World!'. As a non-executable documentation file, it does not contain any code logic, functions, classes, or executable paths that require testing. Test coverage is not applicable for this type of file. No test coverage improvements are needed."
      },
      "refactorings": {
        "file": "README",
        "suggestions": [
          {
            "type": "modernize",
            "location": "README (entire file)",
            "impact": "medium",
            "description": "Convert plain text README to Markdown format (README.md) for better formatting, structure, and GitHub integration",
            "before": "Hello World!\n",
            "after": "# Hello World\n\nWelcome to the Hello World repository!\n\n## Description\n\nThis is a simple Hello World project.\n\n## Getting Started\n\nClone this repository to get started with the Hello World example.\n\n## License\n\nSee LICENSE file for details.",
            "benefits": "Markdown provides better readability, supports formatting (headers, lists, code blocks, links), renders nicely on GitHub, and is the modern standard for repository documentation. This enhances discoverability and professionalism."
          },
          {
            "type": "pattern-improvement",
            "location": "README (structure)",
            "impact": "medium",
            "description": "Add standard README sections to provide comprehensive project documentation",
            "before": "Hello World!\n",
            "after": "# Hello World\n\n## Overview\nA simple Hello World project.\n\n## Installation\n```bash\ngit clone https://github.com/octocat/Hello-World.git\n```\n\n## Usage\nInstructions on how to use this project.\n\n## Contributing\nGuidelines for contributing to this project.\n\n## Contact\nMaintainer information and support channels.",
            "benefits": "Following README best practices improves project accessibility, helps new contributors understand the project quickly, and establishes professional documentation standards. Standard sections make it easier for users to find relevant information."
          },
          {
            "type": "simplify",
            "location": "README (content)",
            "impact": "low",
            "description": "Add a brief description or purpose statement to provide context",
            "before": "Hello World!\n",
            "after": "# Hello World\n\nA demonstration repository showing basic GitHub functionality and serving as a template for new projects.",
            "benefits": "Provides immediate context to visitors about the repository's purpose, making it more useful and informative. Even simple projects benefit from a clear description of their intent or use case."
          }
        ],
        "summary": "The README file is currently a minimal plain text file containing only 'Hello World!'. Key refactoring opportunities include: (1) modernizing to Markdown format (README.md) for better formatting and GitHub integration, (2) adding standard documentation sections (Overview, Installation, Usage, Contributing, Contact) to follow best practices, and (3) including a meaningful description to provide context about the repository's purpose. These changes would significantly improve the repository's professionalism, accessibility, and usefulness to potential users and contributors."
      }
    }
  ],
  "summary": {
    "totalFiles": 1,
    "overallScore": 45,
    "criticalIssues": 0,
    "highPriorityTests": 0,
    "refactoringOpportunities": 3
  },
  "recommendations": [
    {
      "priority": "medium",
      "category": "Documentation Quality",
      "description": "Convert the plain text README to Markdown format (README.md) and add comprehensive documentation sections including project description, installation instructions, usage examples, contribution guidelines, and license information. This will significantly improve the repository's professionalism and accessibility.",
      "files": [
        "README"
      ]
    },
    {
      "priority": "medium",
      "category": "Best Practices",
      "description": "Implement standard README structure with sections for Overview, Installation, Usage, Contributing, and Contact information. This follows modern documentation standards and makes the repository more user-friendly for both users and contributors.",
      "files": [
        "README"
      ]
    },
    {
      "priority": "low",
      "category": "Metadata Enhancement",
      "description": "Add project metadata such as badges for build status, test coverage, version, and license at the top of the README to provide quick project insights and establish credibility.",
      "files": [
        "README"
      ]
    }
  ],
  "metadata": {
    "analyzedAt": "2025-01-10T00:00:00Z",
    "duration": 0,
    "agentVersions": {
      "test-coverage-analyzer": "a34a7c7",
      "code-quality-analyzer": "a8559f9",
      "refactoring-suggester": "af0f9c7"
    }
  }
};

export const invalidReport_stringNumber = (() => {
  const copy = JSON.parse(JSON.stringify(validReport));
  copy.fileReviews[0].codeQuality.issues[0].line = "10";
  return copy;
})();

export const invalidReport_wrongSeverity = (() => {
  const copy = JSON.parse(JSON.stringify(validReport));
  copy.fileReviews[0].codeQuality.issues[0].severity = "catastrophic";
  return copy;
})();


export const invalidReport_outOfBoundsScore = (() => {
  const copy = JSON.parse(JSON.stringify(validReport));
  copy.fileReviews[0].codeQuality.overallScore = 105;
  return copy;
})();

export const invalidReport_missingMetadata = (() => {
  const copy = JSON.parse(JSON.stringify(validReport));
  copy.metadata = null;
  return copy;
})();

export const invalidReport_missingSummary = (() => {
  const copy = JSON.parse(JSON.stringify(validReport));
  copy.summary = null;
  return copy;
})();